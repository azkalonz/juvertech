"""Package approved masters and publish stable website filenames.

Run with Python's standard library: python3 branding/build.py
SVG/PNG artwork in kit/ is the source; no image-generation service is needed.
"""
from pathlib import Path
import shutil
import struct
import zipfile

ROOT = Path(__file__).resolve().parent
ALIASES = {
    "logo-dark.svg": "logo-website-two-tone-dark.svg",
    "logo-light.svg": "logo-website-black.svg",
    "logo-black.svg": "logo-website-black.svg",
    "logo-white.svg": "logo-website-white.svg",
    "logo-compact-dark.svg": "logo-compact-two-tone-dark.svg",
    "logo-compact-light.svg": "logo-compact-black.svg",
    "symbol-dark.svg": "logo-symbol-two-tone-dark.svg",
    "symbol-light.svg": "logo-symbol-two-tone-light.svg",
    "symbol-green.svg": "logo-symbol-green.svg",
    "symbol-black.svg": "logo-symbol-black.svg",
    "symbol-white.svg": "logo-symbol-white.svg",
}


def build_branding():
    for alias, master in ALIASES.items():
        shutil.copyfile(ROOT / "kit" / master, ROOT / alias)
    # favicon.svg is a dedicated small-size master, not a scaled full logo.
    # Package its reviewed PNG exports into a multi-resolution ICO fallback.
    sizes = (16, 32, 48)
    frames = [(ROOT / f"favicon-{size}.png").read_bytes() for size in sizes]
    offset = 6 + 16 * len(frames)
    entries = []
    for size, frame in zip(sizes, frames):
        entries.append(struct.pack("<BBBBHHII", size, size, 0, 0, 1, 32, len(frame), offset))
        offset += len(frame)
    (ROOT / "favicon.ico").write_bytes(
        struct.pack("<HHH", 0, 1, len(frames)) + b"".join(entries) + b"".join(frames)
    )
    (ROOT / "brand-guide.txt").write_text((ROOT / "BRAND_GUIDE.md").read_text())
    files = sorted((ROOT / "kit").glob("*"))
    files += [ROOT / name for name in ALIASES]
    files += [ROOT / name for name in (
        "favicon.svg", "favicon.ico", "favicon-16.png", "favicon-32.png", "favicon-48.png",
        "BRAND_GUIDE.md", "brand-guide.txt", "brand.json",
        "Manrope-OFL.txt", "Barlow-Condensed-OFL.txt", "manrope.woff2",
        "barlow-condensed.ttf", "image-prompts.txt", "build.py",
    )]
    # Stable timestamps and order keep repeated builds from changing the archive.
    with zipfile.ZipFile(ROOT / "juvertech-brand-kit.zip", "w") as bundle:
        for path in sorted(files):
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), (2026, 11, 16, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, path.read_bytes())


if __name__ == "__main__":
    build_branding()
    print("Built approved JT sparkle aliases, favicon and brand kit.")
